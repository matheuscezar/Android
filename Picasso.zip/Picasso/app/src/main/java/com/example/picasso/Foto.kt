package com.example.picasso

data class Foto (
    var albumId : String,
    var id : String,
    var title : String,
    var url : String,
    var thumbnailUrl: String
)