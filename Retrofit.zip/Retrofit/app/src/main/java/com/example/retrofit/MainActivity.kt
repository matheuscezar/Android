package com.example.retrofit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    var retrofit : Retrofit? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        retrofit = Retrofit.Builder()
            .baseUrl("https://viacep.com.br/ws/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        button_carregar.setOnClickListener {
            acessarCEP(edt_cep.text.toString())
        }
    }

    fun acessarCEP(cep : String){
        var cepService : CepService = retrofit!!.create(CepService::class.java)
        var call : Call<CEP> = cepService.recuperarCEP(cep)

        call.enqueue(object : Callback<CEP>{
            override fun onFailure(call: Call<CEP>, t: Throwable) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onResponse(call: Call<CEP>, response: Response<CEP>) {
                if(response.isSuccessful){
                    var cep = response.body()
                    txt_resultado.text = "${cep!!.logradouro} / ${cep!!.localidade}"
                }
            }
        })
    }
}
