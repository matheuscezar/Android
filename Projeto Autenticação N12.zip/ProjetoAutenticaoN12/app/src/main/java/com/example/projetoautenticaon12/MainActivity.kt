package com.example.projetoautenticaon12

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth


class MainActivity : AppCompatActivity() {

    private lateinit var auth : FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        auth = FirebaseAuth.getInstance()


    }


    fun cadastrar(view: View) {
        var intent = Intent(this,CadastrarActivity::class.java)
        startActivity(intent)
    }

    fun login(view: View) {
        val user = auth.currentUser
        if(user == null){
            var intent = Intent(this,LoginActivity::class.java)
            startActivity(intent)
        }else{
            var intent = Intent(this,TelaPrincipalActivity::class.java)
            startActivity(intent)
        }
    }
}
