package com.example.projetoautenticaon12

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_cadastrar.*
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    private lateinit var auth : FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        auth = FirebaseAuth.getInstance()
    }


    fun entrar(view: View){
        auth.signInWithEmailAndPassword(edt_email_login.text.toString(),edt_senha_login.text.toString())
            .addOnCompleteListener(this){task ->
                if(task.isSuccessful){
                    Toast.makeText(this,"Sucesso ao logar", Toast.LENGTH_SHORT).show()
                }else{
                    val resposta = task.exception.toString()
                    Toast.makeText(this,resposta,Toast.LENGTH_SHORT).show()
                }
            }

    }

}
